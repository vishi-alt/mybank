
<link rel="stylesheet" type="text/css" href="assets/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="assets/custom.css">
<!-- <link rel="stylesheet" type="text/css" href="assets/font-awesome.min.css"> -->
<script src='assets/jquery-3.2.1.min.js'></script>
<script src='assets/popper.min.js'></script>
<script src='assets/bootstrap.min.js'></script>
<script src="https://use.fontawesome.com/b3b5303fa3.js"></script>

